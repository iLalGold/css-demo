export const INITIAL = "INITIAL";
export const PLAYING = "PLAYING";
export const PAUSED = "PAUSED";
export const ENDED = "ENDED";
