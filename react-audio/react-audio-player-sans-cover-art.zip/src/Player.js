import React, { useRef, useState } from "react";
import { distanceInWordsStrict } from "date-fns";
import nbLocale from "date-fns/locale/nb";
import { INITIAL, PLAYING, PAUSED, ENDED } from "./enums";

import ToggleIcon from "./ToggleIcon";

const Player = ({ audioFile, title }) => {
  const audioEl = useRef(null);

  const [status, setStatus] = useState(INITIAL);
  const [speed, setSpeed] = useState(1);
  const [currentTimeProcentage, setCurrentTimeProcentage] = useState(0);
  const [currentTimeLeft, setCurrentTimeLeft] = useState(0);
  const [duration, setDuration] = useState(0);

  const onToggleClick = () => {
    const audio = audioEl.current;
    audio.paused ? audio.play() : audio.pause();
  };

  const onSpeedClick = () => {
    const audio = audioEl.current;
    switch (audio.playbackRate) {
      case 1:
        audio.playbackRate = 1.2;
        break;
      case 1.2:
        audio.playbackRate = 1.5;
        break;
      case 1.5:
        audio.playbackRate = 2;
        break;
      default:
        audio.playbackRate = 1;
    }
  };

  const durationInWords = distanceInWordsStrict(
    0,
    // If there is no time left use duration
    ((currentTimeLeft || duration) / speed) * 1000,
    {
      locale: nbLocale
    }
  );

  return (
    <div className="Player">
      <header>
        <h1>{title}</h1>
        <p className={duration || "hidden"}>{durationInWords}</p>
      </header>
      <audio
        onPlaying={() => setStatus(PLAYING)}
        onPause={() => setStatus(PAUSED)}
        onEnded={() => setStatus(ENDED)}
        onRateChange={e => setSpeed(e.currentTarget.playbackRate)}
        onDurationChange={e => setDuration(e.currentTarget.duration)}
        onTimeUpdate={e => {
          setCurrentTimeProcentage(
            (e.currentTarget.currentTime / e.currentTarget.duration) * 100
          );
          setCurrentTimeLeft(
            e.currentTarget.duration - e.currentTarget.currentTime
          );
        }}
        ref={audioEl}
        src={audioFile}
      />
      <div className="controls">
        <button onClick={onToggleClick} className="toggle">
          <ToggleIcon status={status} />
        </button>
        <button onClick={onSpeedClick} className="speed">
          {speed}x
        </button>
      </div>
      <div
        className="progress"
        style={{ width: `${currentTimeProcentage}vw` }}
      />
    </div>
  );
};

export default Player;
